<?php

/**
 * Title: Main Banner
 * Slug: pixel-cyber-security/main-banner
 */

?>

<!-- wp:group {"className":"main-banner","style":{"background":{"backgroundImage":{"url":"<?php echo esc_url(get_parent_theme_file_uri( '/assets/images/banner.png' )); ?>","id":17,"source":"file","title":"banner"},"backgroundSize":"cover"},"dimensions":{"minHeight":"700px"},"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"blockGap":"0","margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained","contentSize":"80%"}} -->
<div class="wp-block-group main-banner" style="min-height:700px;margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:columns {"className":"banner-partition","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}}} -->
<div class="wp-block-columns banner-partition" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:column {"width":"40%","className":"banner-partition-1","style":{"spacing":{"padding":{"right":"40px"}},"border":{"right":{"color":"#c8c7c7","width":"1px"},"top":[],"bottom":[],"left":[]}}} -->
<div class="wp-block-column banner-partition-1" style="border-right-color:#c8c7c7;border-right-width:1px;padding-right:40px;flex-basis:40%"><!-- wp:group {"className":"banner-video-part","style":{"border":{"radius":"20px","color":"#dfdfdf","width":"1px"},"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"margin":{"top":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group banner-video-part has-border-color" style="border-color:#dfdfdf;border-width:1px;border-radius:20px;margin-top:var(--wp--preset--spacing--50);padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:paragraph {"className":"video-text","style":{"elements":{"link":{"color":{"text":"var:preset|color|background"}}}},"textColor":"background","fontFamily":"outfit"} -->
<p class="video-text has-background-color has-text-color has-link-color has-outfit-font-family"><?php esc_html_e('The Best Solution To Help You Secure Your','pixel-cyber-security'); ?> <br><?php esc_html_e('Digital World','pixel-cyber-security'); ?></p>
<!-- /wp:paragraph -->


<!-- wp:group {"className":"popup-position","layout":{"type":"constrained"}} -->
<div class="wp-block-group popup-position"><!-- wp:image {"id":41,"scale":"cover","sizeSlug":"full","linkDestination":"none","className":"banner-img","style":{"border":{"radius":"22px"},"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} -->
<figure class="wp-block-image size-full has-custom-border banner-img" style="margin-top:var(--wp--preset--spacing--40)"><img src="<?php echo esc_url(get_parent_theme_file_uri( '/assets/images/banner-img.png' )); ?>" alt="" class="wp-image-41" style="border-radius:22px;object-fit:cover"/></figure>
<!-- /wp:image -->

<!-- wp:wpzoom-video-popup-block/block {"url":"https://www.youtube.com/watch?v=fNzpcB7ODxQ","text":"","icon":4,"className":"banner-popup","style":{"elements":{"link":{"color":{"text":"var:preset|color|background"}}},"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0","left":"0","right":"0"}}},"textColor":"background"} -->
<a class="wp-block-wpzoom-video-popup-block-block wpzoom-video-popup-block banner-popup has-background-color has-text-color has-link-color" href="https://www.youtube.com/watch?v=fNzpcB7ODxQ" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0" data-popup-width="900px"><span class="wpzoom-video-popup-block_icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" aria-hidden="true"><path d="m2 28.221v-24.522c0-2.8431 2.9657-4.6201 5.2336-3.1985l20.935 12.261c2.4424 1.4216 2.4424 5.1531 0 6.5747l-20.935 12.261c-2.2679 1.2439-5.2336-0.53308-5.2336-3.3762z" fill="currentColor"></path></svg></span></a>
<!-- /wp:wpzoom-video-popup-block/block --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"42px","className":"part-space"} -->
<div style="height:42px" aria-hidden="true" class="wp-block-spacer part-space"></div>
<!-- /wp:spacer -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"className":"banner-clint-part","layout":{"type":"constrained"}} -->
<div class="wp-block-group banner-clint-part"><!-- wp:group {"style":{"border":{"radius":"20px","color":"#dfdfdf","width":"1px"},"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"},"margin":{"top":"var:preset|spacing|50"}}},"backgroundColor":"accent","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-border-color has-accent-background-color has-background" style="border-color:#dfdfdf;border-width:1px;border-radius:20px;margin-top:var(--wp--preset--spacing--50);padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:image {"id":40,"scale":"cover","sizeSlug":"full","linkDestination":"none","className":"client-img","style":{"border":{"radius":"22px"},"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
<figure class="wp-block-image size-full has-custom-border client-img" style="margin-top:0;margin-bottom:0"><img src="<?php echo esc_url(get_parent_theme_file_uri( '/assets/images/client.png' )); ?>" alt="" class="wp-image-40" style="border-radius:22px;object-fit:cover"/></figure>
<!-- /wp:image -->

<!-- wp:group {"className":"client-detail","style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"top":"0","bottom":"0"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group client-detail" style="margin-top:0;margin-bottom:0;padding-top:0;padding-bottom:0"><!-- wp:paragraph {"className":"client-count","style":{"elements":{"link":{"color":{"text":"var:preset|color|background"}}},"typography":{"fontSize":"28px"}},"textColor":"background"} -->
<p class="client-count has-background-color has-text-color has-link-color" style="font-size:28px"><strong><?php esc_html_e('26K+','pixel-cyber-security'); ?></strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"client-text","style":{"elements":{"link":{"color":{"text":"var:preset|color|background"}}}},"textColor":"background","fontFamily":"outfit"} -->
<p class="client-text has-background-color has-text-color has-link-color has-outfit-font-family"><?php esc_html_e('Happy Clients','pixel-cyber-security'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"counter-detail","layout":{"type":"constrained"}} -->
<div class="wp-block-group counter-detail"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"counter-count-1","style":{"elements":{"link":{"color":{"text":"var:preset|color|background"}}},"typography":{"fontStyle":"normal","fontWeight":"500","fontSize":"28px"}},"textColor":"background"} -->
<p class="counter-count-1 has-background-color has-text-color has-link-color" style="font-size:28px;font-style:normal;font-weight:500"><?php esc_html_e('569M+','pixel-cyber-security'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"counter-text","style":{"elements":{"link":{"color":{"text":"var:preset|color|background"}}},"typography":{"fontStyle":"normal","fontWeight":"300"},"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}}},"textColor":"background","fontSize":"medium","fontFamily":"outfit"} -->
<p class="counter-text has-background-color has-text-color has-link-color has-outfit-font-family has-medium-font-size" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;font-style:normal;font-weight:300"><?php esc_html_e('Monitored Globally','pixel-cyber-security'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"counter-count-1","style":{"elements":{"link":{"color":{"text":"var:preset|color|background"}}},"typography":{"fontSize":"28px","fontStyle":"normal","fontWeight":"500"}},"textColor":"background","fontFamily":"outfit"} -->
<p class="counter-count-1 has-background-color has-text-color has-link-color has-outfit-font-family" style="font-size:28px;font-style:normal;font-weight:500"><?php esc_html_e('19K+','pixel-cyber-security'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"counter-text","style":{"elements":{"link":{"color":{"text":"var:preset|color|background"}}},"typography":{"fontStyle":"normal","fontWeight":"300"},"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0","left":"0","right":"0"}}},"textColor":"background","fontSize":"medium","fontFamily":"outfit"} -->
<p class="counter-text has-background-color has-text-color has-link-color has-outfit-font-family has-medium-font-size" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;font-style:normal;font-weight:300"><?php esc_html_e('Network Sensors','pixel-cyber-security'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"60%","className":"banner-partition-2","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"0","left":"0","right":"0"}}}} -->
<div class="wp-block-column banner-partition-2" style="padding-top:var(--wp--preset--spacing--70);padding-right:0;padding-bottom:0;padding-left:0;flex-basis:60%"><!-- wp:group {"className":"slider-box owl-carousel","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group slider-box owl-carousel" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"className":"slider-content","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group slider-content" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:heading {"level":5,"style":{"elements":{"link":{"color":{"text":"#51cbcc"}}},"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0","left":"0","right":"0"}},"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"700","textTransform":"capitalize"},"color":{"text":"#51cbcc"}},"fontFamily":"comic-neue"} -->
<h5 class="wp-block-heading has-text-color has-link-color has-comic-neue-font-family" style="color:#51cbcc;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;font-size:18px;font-style:normal;font-weight:700;text-transform:capitalize"><?php esc_html_e('Welcome To Ethical Hacking','pixel-cyber-security'); ?></h5>
<!-- /wp:heading -->

<!-- wp:heading {"style":{"elements":{"link":{"color":{"text":"var:preset|color|background"}}},"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"bottom":"20px"}},"typography":{"fontStyle":"normal","fontWeight":"600","fontSize":"40px"}},"textColor":"background","fontFamily":"outfit"} -->
<h2 class="wp-block-heading has-background-color has-text-color has-link-color has-outfit-font-family" style="margin-bottom:20px;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;font-size:40px;font-style:normal;font-weight:600"><?php esc_html_e('Protect What Matters: Expert Ethical Hacking','pixel-cyber-security'); ?> &amp; <?php esc_html_e('Security Services','pixel-cyber-security'); ?></h2>
<!-- /wp:heading -->

<!-- wp:columns {"className":"slider-btn-text","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"},"blockGap":{"top":"0","left":"0"}}}} -->
<div class="wp-block-columns slider-btn-text" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:column {"width":"20%","className":"slider-button","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}}} -->
<div class="wp-block-column slider-button" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;flex-basis:20%"><!-- wp:buttons {"className":"slider-btn","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"flex","justifyContent":"left"}} -->
<div class="wp-block-buttons slider-btn" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:button {"textColor":"background","className":"slider-btnns","style":{"elements":{"link":{"color":{"text":"var:preset|color|background"}}},"spacing":{"padding":{"left":"0","right":"0","top":"0","bottom":"0"}}}} -->
<div class="wp-block-button slider-btnns"><a class="wp-block-button__link has-background-color has-text-color has-link-color wp-element-button" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><?php esc_html_e('Discover More','pixel-cyber-security'); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"slider-cont","style":{"elements":{"link":{"color":{"text":"var:preset|color|background"}}},"layout":{"selfStretch":"fit","flexSize":null},"typography":{"fontSize":"16px"}},"textColor":"background"} -->
<p class="slider-cont has-background-color has-text-color has-link-color" style="font-size:16px"><?php esc_html_e('It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout','pixel-cyber-security'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:group {"className":"slider-image","style":{"spacing":{"margin":{"top":"70px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group slider-image" style="margin-top:70px"><!-- wp:image {"id":102,"sizeSlug":"full","linkDestination":"none","className":"slider-img"} -->
<figure class="wp-block-image size-full slider-img"><img src="<?php echo esc_url(get_parent_theme_file_uri( '/assets/images/slide-1.png' )); ?>" alt="" class="wp-image-102"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"slider-content","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group slider-content" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:heading {"level":5,"style":{"elements":{"link":{"color":{"text":"#51cbcc"}}},"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0","left":"0","right":"0"}},"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"700","textTransform":"capitalize"},"color":{"text":"#51cbcc"}},"fontFamily":"comic-neue"} -->
<h5 class="wp-block-heading has-text-color has-link-color has-comic-neue-font-family" style="color:#51cbcc;margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;font-size:18px;font-style:normal;font-weight:700;text-transform:capitalize"><?php esc_html_e('Welcome To Ethical Hacking','pixel-cyber-security'); ?></h5>
<!-- /wp:heading -->

<!-- wp:heading {"style":{"elements":{"link":{"color":{"text":"var:preset|color|background"}}},"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"bottom":"20px"}},"typography":{"fontStyle":"normal","fontWeight":"600","fontSize":"40px"}},"textColor":"background","fontFamily":"outfit"} -->
<h2 class="wp-block-heading has-background-color has-text-color has-link-color has-outfit-font-family" style="margin-bottom:20px;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;font-size:40px;font-style:normal;font-weight:600"><?php esc_html_e('Protect What Matters: Expert Ethical Hacking','pixel-cyber-security'); ?> &amp; <?php esc_html_e('Security Services','pixel-cyber-security'); ?></h2>
<!-- /wp:heading -->

<!-- wp:columns {"className":"slider-btn-text","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"},"blockGap":{"top":"0","left":"0"}}}} -->
<div class="wp-block-columns slider-btn-text" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:column {"width":"20%","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}}} -->
<div class="wp-block-column" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;flex-basis:20%"><!-- wp:buttons {"className":"slider-btn","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"flex","justifyContent":"left"}} -->
<div class="wp-block-buttons slider-btn" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:button {"textColor":"background","className":"slider-btnns","style":{"elements":{"link":{"color":{"text":"var:preset|color|background"}}},"spacing":{"padding":{"left":"0","right":"0","top":"0","bottom":"0"}}}} -->
<div class="wp-block-button slider-btnns"><a class="wp-block-button__link has-background-color has-text-color has-link-color wp-element-button" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><?php esc_html_e('Discover More','pixel-cyber-security'); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"slider-cont","style":{"elements":{"link":{"color":{"text":"var:preset|color|background"}}},"layout":{"selfStretch":"fit","flexSize":null},"typography":{"fontSize":"16px"}},"textColor":"background"} -->
<p class="slider-cont has-background-color has-text-color has-link-color" style="font-size:16px"><?php esc_html_e('It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout','pixel-cyber-security'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:group {"className":"slider-image","style":{"spacing":{"margin":{"top":"70px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group slider-image" style="margin-top:70px"><!-- wp:image {"id":102,"sizeSlug":"full","linkDestination":"none","className":"slider-img"} -->
<figure class="wp-block-image size-full slider-img"><img src="<?php echo esc_url(get_parent_theme_file_uri( '/assets/images/slide-2.png' )); ?>" alt="" class="wp-image-102"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->