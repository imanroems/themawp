<?php
 /**
  * Title: Main Header
  * Slug: pixel-cyber-security/main-header
  */
?>

<!-- wp:group {"className":"header-wrap","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"backgroundColor":"partial","layout":{"type":"constrained","contentSize":"100%"}} -->
<div class="wp-block-group header-wrap has-partial-background-color has-background" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"className":"top-border","layout":{"type":"constrained","contentSize":"80%"}} -->
<div class="wp-block-group top-border"><!-- wp:columns {"className":"upper-header-inner","style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"right":"0","left":"0","top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"},"blockGap":{"top":"0","left":"0"}}}} -->
<div class="wp-block-columns upper-header-inner" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--20);padding-right:0;padding-bottom:var(--wp--preset--spacing--20);padding-left:0"><!-- wp:column {"verticalAlignment":"center","width":"30%","className":"logo-box"} -->
<div class="wp-block-column is-vertically-aligned-center logo-box" style="flex-basis:30%"><!-- wp:site-title {"textAlign":"left","style":{"typography":{"fontSize":"28px","fontStyle":"normal","fontWeight":"700"},"elements":{"link":{"color":{"text":"var:preset|color|background"}}}},"textColor":"background","fontFamily":"outfit"} /--></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"50%","className":"banner-social-icon"} -->
<div class="wp-block-column is-vertically-aligned-center banner-social-icon" style="flex-basis:50%"><!-- wp:navigation {"textColor":"background","overlayBackgroundColor":"white","overlayTextColor":"heading","metadata":{"ignoredHookedBlocks":["woocommerce/customer-account","woocommerce/mini-cart"]},"className":"header-menu","style":{"typography":{"fontStyle":"normal","fontWeight":"500","fontSize":"16px"},"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"flex","justifyContent":"left"}} -->
<!-- wp:navigation-link {"label":"Home","type":"","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-link {"label":"About","type":"","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-link {"label":"Services","type":"","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-link {"label":"Pages","type":"","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-submenu {"label":"Blog","type":"","url":"#","kind":"custom"} -->
    <!-- wp:navigation-link {"label":"Page 1","type":"","url":"#","kind":"custom","className":""} /-->

    <!-- wp:navigation-link {"label":"Page 2","type":"","url":"#","kind":"custom","className":""} /-->
<!-- /wp:navigation-submenu -->

<!-- wp:navigation-link {"label":"Buy Now","type":"link","opensInNewTab":true,"url":"https://www.themepixels.net/products/ethical-hacking-wordpress-theme/","kind":"custom","isTopLevelLink":true,"className":"buy-now-btn"} /-->
<!-- /wp:navigation --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"20%","className":"btn-box"} -->
<div class="wp-block-column is-vertically-aligned-center btn-box" style="flex-basis:20%"><!-- wp:buttons {"style":{"spacing":{"blockGap":{"top":"var:preset|spacing|20","left":"var:preset|spacing|20"}}},"layout":{"type":"flex","justifyContent":"right"}} -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"primary","textColor":"white","className":"hdr-btn2","style":{"typography":{"fontSize":"14px","fontStyle":"normal","fontWeight":"500"},"spacing":{"padding":{"left":"20px","right":"20px","top":"8px","bottom":"8px"}},"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"border":{"radius":"10px"}},"fontFamily":"outfit"} -->
<div class="wp-block-button hdr-btn2"><a class="wp-block-button__link has-white-color has-primary-background-color has-text-color has-background has-link-color has-outfit-font-family has-custom-font-size wp-element-button" style="border-radius:10px;padding-top:8px;padding-right:20px;padding-bottom:8px;padding-left:20px;font-size:14px;font-style:normal;font-weight:500"><?php esc_html_e('Get a Quote','pixel-cyber-security'); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->