<?php
 /**
  * Title: Footer Columns
  * Slug: pixel-cyber-security/footer-columns
  */
?>

<!-- wp:group {"className":"footer-wrap","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}},"color":{"background":"#141313"}},"layout":{"type":"constrained","contentSize":"80%"}} -->
<div class="wp-block-group footer-wrap has-background" style="background-color:#141313;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:spacer {"height":"43px"} -->
<div style="height:43px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"align":"wide","className":"footer-box","style":{"spacing":{"padding":{"top":"0px","bottom":"0px","right":"0px","left":"0px"},"blockGap":{"top":"30px","left":"30px"}}}} -->
<div class="wp-block-columns alignwide footer-box" style="padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px"><!-- wp:column {"verticalAlignment":"top","width":"35%","className":"box-1 wow bounceInUp"} -->
<div class="wp-block-column is-vertically-aligned-top box-1 wow bounceInUp" style="flex-basis:35%"><!-- wp:group {"className":"footer-logo-row","layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group footer-logo-row"><!-- wp:site-logo /-->

<!-- wp:site-title {"style":{"typography":{"fontStyle":"normal","fontWeight":"700","fontSize":"28px"},"elements":{"link":{"color":{"text":"var:preset|color|primary"}}}},"textColor":"primary","fontFamily":"outfit"} /--></div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"footer-text","style":{"typography":{"fontSize":"14px","fontStyle":"normal","fontWeight":"400"},"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontFamily":"outfit"} -->
<p class="footer-text has-white-color has-text-color has-link-color has-outfit-font-family" style="font-size:14px;font-style:normal;font-weight:400"><?php esc_html_e('Lorem Ipsum&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.','pixel-cyber-security'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"","className":"box-2 wow bounceInUp","style":{"spacing":{"blockGap":"24px"}}} -->
<div class="wp-block-column box-2 wow bounceInUp"><!-- wp:heading {"level":6,"style":{"typography":{"fontStyle":"normal","fontWeight":"600","fontSize":"24px"},"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontFamily":"outfit"} -->
<h6 class="wp-block-heading has-white-color has-text-color has-link-color has-outfit-font-family" style="font-size:24px;font-style:normal;font-weight:600"><?php esc_html_e('Our Link','pixel-cyber-security'); ?></h6>
<!-- /wp:heading -->

<!-- wp:navigation {"textColor":"white","overlayMenu":"never","className":"is-style-justify-right","style":{"spacing":{"blockGap":"var:preset|spacing|110"},"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"}},"fontFamily":"outfit","layout":{"type":"flex","orientation":"vertical"}} -->
<!-- wp:navigation-link {"label":"About Us","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-link {"label":"Services","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-link {"label":"FAQ","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-link {"label":"Blog","url":"#","kind":"custom","isTopLevelLink":true} /-->
<!-- /wp:navigation --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"","className":"box-3 wow bounceInUp","style":{"spacing":{"blockGap":"24px"}}} -->
<div class="wp-block-column box-3 wow bounceInUp"><!-- wp:heading {"level":6,"style":{"typography":{"fontStyle":"normal","fontWeight":"600","fontSize":"24px"},"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontFamily":"outfit"} -->
<h6 class="wp-block-heading has-white-color has-text-color has-link-color has-outfit-font-family" style="font-size:24px;font-style:normal;font-weight:600"><?php esc_html_e('Contact Us','pixel-cyber-security'); ?></h6>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"}},"textColor":"white","fontFamily":"outfit"} -->
<p class="has-white-color has-text-color has-link-color has-outfit-font-family" style="font-size:16px;font-style:normal;font-weight:400"><?php esc_html_e('your location here','pixel-cyber-security'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"},"spacing":{"margin":{"top":"var:preset|spacing|20"}}},"textColor":"white","fontFamily":"outfit"} -->
<p class="has-white-color has-text-color has-link-color has-outfit-font-family" style="margin-top:var(--wp--preset--spacing--20);font-size:16px;font-style:normal;font-weight:400"><?php esc_html_e('+12 3456789123','pixel-cyber-security'); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"},"spacing":{"margin":{"top":"var:preset|spacing|20"}}},"textColor":"white","fontFamily":"outfit"} -->
<p class="has-white-color has-text-color has-link-color has-outfit-font-family" style="margin-top:var(--wp--preset--spacing--20);font-size:16px;font-style:normal;font-weight:400"><?php esc_html_e('support@example.com','pixel-cyber-security'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"","className":"box-4 wow bounceInUp","style":{"spacing":{"blockGap":"24px"}}} -->
<div class="wp-block-column box-4 wow bounceInUp"><!-- wp:heading {"level":6,"style":{"typography":{"fontStyle":"normal","fontWeight":"600","fontSize":"24px"},"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontFamily":"outfit"} -->
<h6 class="wp-block-heading has-white-color has-text-color has-link-color has-outfit-font-family" style="font-size:24px;font-style:normal;font-weight:600"><?php esc_html_e('Our Gallery','pixel-cyber-security'); ?></h6>
<!-- /wp:heading -->

<!-- wp:gallery {"columns":2,"linkTo":"none","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|20","left":"var:preset|spacing|20"}}}} -->
<figure class="wp-block-gallery has-nested-images columns-2 is-cropped"><!-- wp:image {"id":192,"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url(get_parent_theme_file_uri( '/assets/images/slide-2.png' )); ?>" alt="" class="wp-image-192"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":189,"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url(get_parent_theme_file_uri( '/assets/images/about-2.png' )); ?>" alt="" class="wp-image-189"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":190,"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url(get_parent_theme_file_uri( '/assets/images/slide-1.png' )); ?>" alt="" class="wp-image-190"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":191,"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="<?php echo esc_url(get_parent_theme_file_uri( '/assets/images/banner-img.png' )); ?>" alt="" class="wp-image-191"/></figure>
<!-- /wp:image --></figure>
<!-- /wp:gallery --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"43px"} -->
<div style="height:43px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"rights-box-upper","style":{"spacing":{"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30","left":"0","right":"0"}}},"backgroundColor":"primary","layout":{"type":"constrained","contentSize":"80%"}} -->
<div class="wp-block-group rights-box-upper has-primary-background-color has-background" style="padding-top:var(--wp--preset--spacing--30);padding-right:0;padding-bottom:var(--wp--preset--spacing--30);padding-left:0"><!-- wp:paragraph {"align":"center","className":"rights-text","style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"600"},"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white","fontFamily":"outfit"} -->
<p class="has-text-align-center rights-text has-white-color has-text-color has-link-color has-outfit-font-family" style="font-size:16px;font-style:normal;font-weight:600"><a href="<?php echo esc_url(PIXEL_CYBER_SECURITY_FREE_BUY_NOW); ?>" target="_blank"><strong><?php esc_html_e('Pixel Cyber Security','pixel-cyber-security'); ?></strong> <?php esc_html_e('All Rights Reserved.','pixel-cyber-security'); ?></a></p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"primary","textColor":"white","className":"back-to-top","style":{"border":{"radius":"50%"},"elements":{"link":{"color":{"text":"var:preset|color|white"}}}}} -->
<div class="wp-block-button back-to-top"><a class="wp-block-button__link has-white-color has-primary-background-color has-text-color has-background has-link-color wp-element-button" style="border-radius:50%">.</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->